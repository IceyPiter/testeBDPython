# Projeto de CRUD com Django
Desenvolvimento de um projeto simples com o framework Django
